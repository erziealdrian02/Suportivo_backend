<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Codeigniter Multilevel Menu Basic Example</title>
</head>
<body>
	<?php echo $this->multi_menu->render('Item-0'); ?>
</body>
</html>