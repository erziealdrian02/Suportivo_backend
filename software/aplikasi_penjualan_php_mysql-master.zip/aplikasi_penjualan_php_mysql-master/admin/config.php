<?php 
mysql_connect("localhost","root","xxx");
mysql_select_db("malasngoding_kios");
?>